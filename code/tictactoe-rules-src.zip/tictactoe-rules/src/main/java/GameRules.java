/*
 * $Id: GameRules.java,v 1.8 2014/03/11 17:30:31 ssantos Exp $
 *
 * Copyright (c) Present Technologies Lda., All Rights Reserved.
 * (www.present-technologies.com)
 *
 * This software is the proprietary information of Present Technologies Lda.
 * Use is subject to license terms.
 *
 * Last changed on $Date: 2014/03/11 17:30:31 $
 * Last changed by $Author: ssantos $
 */

import java.util.List;
import java.util.Random;

import com.presenttechnologies.phunegaming.games.rules.frameworks.boardgame.Board;
import com.presenttechnologies.phunegaming.games.rules.frameworks.boardgame.BoardGameState;
import com.presenttechnologies.phunegaming.games.rules.frameworks.boardgame.JavaBoardGameRules;
import com.presenttechnologies.phunegaming.games.rules.frameworks.boardgame.View;
import com.presenttechnologies.phunegaming.games.rules.frameworks.boardgame.Board.Cell;
import com.presenttechnologies.phunegaming.worker.rules.java.spi.JavaBotRules;
import com.presenttechnologies.phunegaming.worker.rules.java.spi.entities.EvaluationResult;
import com.presenttechnologies.phunegaming.worker.rules.java.spi.entities.Move;
import com.presenttechnologies.phunegaming.worker.rules.java.spi.exceptions.PhuneMappingException;

/**
 * Java rules for the Tic-Tac-Toe game.
 * 
 * @author Avelino Martins
 * @version $Revision: 1.8 $
 */
public class GameRules extends JavaBoardGameRules implements JavaBotRules {
    public static final int SEQUENCE_SIZE = 3;

    /*
     * (non-Javadoc)
     * @see
     * com.presenttechnologies.phunegaming.core.business.worker.JavaGameRulesEngine#createStateForNewMatch(java.util
     * .List)
     */
    @Override
    public void createStateForNewMatch(List<Long> players) {
        gameState = BoardGameState.BoardGameStateBuilder.newState(Board.Origin.TOP_LEFT, 3, 3).withPlayers(players)
                .build();
    }

    /**
     * (non-Javadoc)
     *
     * @see com.presenttechnologies.phunegaming.worker.rules.java.frameworks.base.JavaGameRules#executeMove(com.presenttechnologies.phunegaming
     *      .core.entities.dto.PlayerMoveDTO, java.util.Map)
     */
    @Override
    public EvaluationResult evaluateMove(Move move) {

        EvaluationResult evaluationResult = new EvaluationResult();
        MoveContent content = null;
        try {
            content = move.mapContentTo(MoveContent.class);
        } catch (PhuneMappingException e) {
            evaluationResult.setEvaluationResultType(EvaluationResult.Type.INTERNAL_ERROR);
            return evaluationResult;
        }

        int line = content.getPosY();
        int column = content.getPosX();

        if (moveFailsGenericValidation(move, evaluationResult, line, column)) {
            return evaluationResult;
        }

        return evaluateMove(move, evaluationResult, line, column);
    }

    /*
     * (non-Javadoc)
     * @see
     * com.presenttechnologies.phunegaming.worker.rules.java.JavaGameRules#createAndExecuteBotMove(com.presenttechnologies
     * .phunegaming.core.entities.dto.PlayerMoveDTO)
     */
    @Override
    public EvaluationResult createAndExecuteBotMove(Move prefilledMove) {
        EvaluationResult result = new EvaluationResult();
        MoveContent botMove = new MoveContent();

        if (gameState.getBoard().isEmpty()) {
            // First move
            fillFirstMove(botMove);

            prefilledMove.setContent(botMove);
            return evaluateMove(prefilledMove, result, botMove.getPosY(), botMove.getPosX());
        }

        // 1) Win: If you have two in a row, play the third to get three in a row.
        List<View> winningRows = gameState.getBoard().searchSequences(prefilledMove.getPlayerId(), 3, 1);
        if (!winningRows.isEmpty()) {
            View winningRow = winningRows.get(0);
            // The the position to play, i.e the first empty cell
            Cell firstEmptyCell = winningRow.getFirstEmptyCell();
            botMove.setPosX(firstEmptyCell.getColumn());
            botMove.setPosY(firstEmptyCell.getLine());

            prefilledMove.setContent(botMove);
            return evaluateMove(prefilledMove, result, botMove.getPosY(), botMove.getPosX());
        }

        // 2) Block: If the opponent has two in a row, play the third to block them.
        Long otherPlayerId = getOtherPlayerThan(prefilledMove.getPlayerId());
        winningRows = gameState.getBoard().searchSequences(otherPlayerId, 3, 1);
        if (!winningRows.isEmpty()) {
            View winningRow = winningRows.get(0);
            Cell firstEmptyCell = winningRow.getFirstEmptyCell();
            assert (firstEmptyCell != null);

            botMove.setPosX(firstEmptyCell.getColumn());
            botMove.setPosY(firstEmptyCell.getLine());

            prefilledMove.setContent(botMove);
            return evaluateMove(prefilledMove, result, botMove.getPosY(), botMove.getPosX());
        }

        // 5) Center: Play the center.
        if (gameState.getBoard().getCellAt(1, 1).isEmpty()) {
            botMove.setPosX(1);
            botMove.setPosY(1);

            prefilledMove.setContent(botMove);
            return evaluateMove(prefilledMove, result, botMove.getPosY(), botMove.getPosX());
        }

        // 3) Fork: Create an opportunity where you can win in two ways.
        if (gameState.getBoard().getCellAt(0, 0).wasSetBy(otherPlayerId)
                && gameState.getBoard().getCellAt(2, 2).wasSetBy(otherPlayerId)
                || gameState.getBoard().getCellAt(0, 2).wasSetBy(otherPlayerId)
                && gameState.getBoard().getCellAt(2, 0).wasSetBy(otherPlayerId)) {

            // Opponent has opposite corners , play cell at one side
            fillMoveWithEmptySideCell(botMove);
            prefilledMove.setContent(botMove);
            return evaluateMove(prefilledMove, result, botMove.getPosY(), botMove.getPosX());
        }

        // 6) Empty Corner: Play an empty corner.
        if (gameState.getBoard().getCellAt(0, 0).isEmpty()) {
            botMove.setPosY(0);
            botMove.setPosX(0);
        } else if (gameState.getBoard().getCellAt(0, 2).isEmpty()) {
            botMove.setPosY(0);
            botMove.setPosX(2);
        } else if (gameState.getBoard().getCellAt(2, 0).isEmpty()) {
            botMove.setPosY(2);
            botMove.setPosX(0);
        } else if (gameState.getBoard().getCellAt(2, 2).isEmpty()) {
            botMove.setPosY(2);
            botMove.setPosX(2);
        } else {
            // 7) Empty Side: Play an empty side.
            fillMoveWithEmptySideCell(botMove);
        }

        prefilledMove.setContent(botMove);
        return evaluateMove(prefilledMove, result, botMove.getPosY(), botMove.getPosX());
    }

    /**
     * @param botMove
     */
    private void fillFirstMove(MoveContent botMove) {
        Random rand = new Random();
        int cellPos = rand.nextInt(100);

        // Center = 30% chances
        if (cellPos >= 70) {
            botMove.setPosY(2);
            botMove.setPosX(2);

            return;
        }

        // Corners = ~12% chances each
        if (cellPos >= 58) {
            botMove.setPosY(0);
            botMove.setPosX(1);

            return;
        }

        if (cellPos >= 46) {
            botMove.setPosY(2);
            botMove.setPosX(0);

            return;
        }

        if (cellPos >= 34) {
            botMove.setPosY(0);
            botMove.setPosX(2);

            return;
        }

        if (cellPos >= 20) {
            botMove.setPosY(0);
            botMove.setPosX(0);

            return;
        }

        // Side cells = 5% chances each
        if (cellPos >= 15) {
            botMove.setPosY(0);
            botMove.setPosX(1);

            return;
        }

        if (cellPos >= 10) {
            botMove.setPosY(1);
            botMove.setPosX(0);

            return;
        }

        if (cellPos >= 5) {
            botMove.setPosY(1);
            botMove.setPosX(2);

            return;
        }

        botMove.setPosY(2);
        botMove.setPosX(1);
    }

    /**
     * @param botMove
     */
    private void fillMoveWithEmptySideCell(MoveContent botMove) {
        if (gameState.getBoard().getCellAt(0, 1).isEmpty()) {
            botMove.setPosY(0);
            botMove.setPosX(1);
        } else if (gameState.getBoard().getCellAt(1, 0).isEmpty()) {
            botMove.setPosY(1);
            botMove.setPosX(0);
        } else if (gameState.getBoard().getCellAt(1, 2).isEmpty()) {
            botMove.setPosY(1);
            botMove.setPosX(2);
        } else if (gameState.getBoard().getCellAt(2, 1).isEmpty()) {
            botMove.setPosY(2);
            botMove.setPosX(1);
        } else {
            assert (false);
        }
    }

    /**
     * @param playerId
     * @return
     */
    private Long getOtherPlayerThan(Long playerId) {
        for (Long player : gameState.getPlayers()) {
            if (!player.equals(playerId)) {
                return player;
            }
        }
        return null;
    }

    /**
     * @param move
     * @param line
     * @param column
     * @return
     */
    private EvaluationResult evaluateMove(Move move, EvaluationResult evaluationResult, int line, int column) {
        Long playerId = move.getPlayerId();
        gameState.executeMove(line, column, playerId);

        List<View> sequences = gameState.getBoard().searchSequencesContaining(playerId, line, column, SEQUENCE_SIZE, 0);
        if (!sequences.isEmpty()) {
            evaluationResult.setEvaluationResultType(EvaluationResult.Type.MATCH_END_WINNER);
            evaluationResult.setWinnerPlayerId(playerId);
            View view = sequences.get(0);
            int result = 0;
            switch (view.getType()) {
                case COLUMN:
                    result = view.getStart().getColumn();
                    break;
                case LINE:
                    result = view.getStart().getLine() + 3;
                    break;
                case LEFT_DIAGONAL:
                    result = 6;
                    break;
                case RIGHT_DIAGONAL:
                    result = 7;
                    break;
            }
            evaluationResult.setEvaluationContent(Integer.valueOf(result).toString());
            return evaluationResult;
        }

        gameState.markMoveAsValid();

        // Check draws
        if (!gameState.getBoard().sequenceIsYetPossible(getIdOfNextPlayer(), gameState.getPlayers(), SEQUENCE_SIZE)) {
            evaluationResult.setWinnerPlayerId(0L);
            evaluationResult.setEvaluationResultType(EvaluationResult.Type.MATCH_END_DRAW);
            return evaluationResult;
        }

        evaluationResult.setEvaluationResultType(EvaluationResult.Type.SUCCESS);
        return evaluationResult;
    }

}
