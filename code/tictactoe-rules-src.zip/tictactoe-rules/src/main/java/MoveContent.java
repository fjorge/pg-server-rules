/*
 * $Id: MoveContent.java,v 1.1 2014/01/20 10:18:56 amartins Exp $
 *
 * Copyright (c) Present Technologies Lda., All Rights Reserved.
 * (www.present-technologies.com)
 *
 * This software is the proprietary information of Present Technologies Lda.
 * Use is subject to license terms.
 *
 * Last changed on $Date: 2014/01/20 10:18:56 $
 * Last changed by $Author: amartins $
 */

/**
 * A Tic Tac Toe move content representation.
 * 
 * @author Avelino Martins
 * @version $Revision: 1.1 $
 */
public class MoveContent {

    private int posX;

    private int posY;

    /**
     * Gets the posX.
     * 
     * @return the posX
     */
    public int getPosX() {
        return posX;
    }

    /**
     * Sets the posX.
     * 
     * @param posX the posX to set
     */
    public void setPosX(int posX) {
        this.posX = posX;
    }

    /**
     * Gets the posY.
     * 
     * @return the posY
     */
    public int getPosY() {
        return posY;
    }

    /**
     * Sets the posY.
     * 
     * @param posY the posY to set
     */
    public void setPosY(int posY) {
        this.posY = posY;
    }
}
