/*
 * $Id: BotTests.java,v 1.4 2014/03/11 17:30:31 ssantos Exp $
 *
 * Copyright (c) Present Technologies Lda., All Rights Reserved.
 * (www.present-technologies.com)
 *
 * This software is the proprietary information of Present Technologies Lda.
 * Use is subject to license terms.
 *
 * Last changed on $Date: 2014/03/11 17:30:31 $
 * Last changed by $Author: ssantos $
 */
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.presenttechnologies.phunegaming.games.rules.frameworks.boardgame.SequencesBoard;
import com.presenttechnologies.phunegaming.worker.rules.java.spi.entities.EvaluationResult;
import com.presenttechnologies.phunegaming.worker.rules.java.spi.entities.Move;

/**
 * <Class description>
 * 
 * @author Avelino Martins
 * @version $Revision: 1.4 $
 */
public class BotTests {

    private static List<Long> players = new ArrayList<>();

    @BeforeClass
    public static void setup() {
        players.add(1L);
        players.add(2L);
    }

    @Test
    public void testBotFirstMove() {
        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);

        Move prefilledMove = new Move(1L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.SUCCESS, result.getEvaluationResultType());
    }

    @Test
    public void testColumnMiddlePieceWinBlockMove() {

        int[][] boardModel = new int[][] { { 1, 0, 2 }, { 0, 1, 0 }, { 0, 0, 2 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(1L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.SUCCESS, result.getEvaluationResultType());
    }

    @Test
    public void testColumnMiddlePieceWinMove() {

        int[][] boardModel = new int[][] { { 1, 0, 2 }, { 0, 0, 0 }, { 1, 0, 2 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(1L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.MATCH_END_WINNER, result.getEvaluationResultType());
    }

    @Test
    public void testColumnEdgePieceWinMove() {

        int[][] boardModel = new int[][] { { 1, 0, 2 }, { 1, 0, 0 }, { 0, 0, 2 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(1L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.MATCH_END_WINNER, result.getEvaluationResultType());
    }

    @Test
    public void testLineMiddlePieceWinMove() {

        int[][] boardModel = new int[][] { { 1, 0, 2 }, { 0, 0, 0 }, { 1, 0, 1 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(1L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.MATCH_END_WINNER, result.getEvaluationResultType());
    }

    @Test
    public void testLineEdgePieceWinMove() {

        int[][] boardModel = new int[][] { { 1, 1, 0 }, { 0, 0, 0 }, { 0, 2, 2 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(1L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.MATCH_END_WINNER, result.getEvaluationResultType());
    }

    @Test
    public void testDiagMiddlePieceWinMove() {

        int[][] boardModel = new int[][] { { 1, 0, 2 }, { 0, 0, 0 }, { 2, 0, 1 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(1L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.MATCH_END_WINNER, result.getEvaluationResultType());
    }

    @Test
    public void testDiagEdgePieceWinMove() {

        int[][] boardModel = new int[][] { { 2, 0, 0 }, { 2, 1, 0 }, { 1, 0, 2 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(1L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.MATCH_END_WINNER, result.getEvaluationResultType());
    }

    @Test
    public void testWinningCondition() {

        int[][] boardModel = new int[][] { { 1, 0, 1 }, { 1, 2, 1 }, { 2, 0, 2 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(2L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.MATCH_END_WINNER, result.getEvaluationResultType());
    }

    @Test
    public void testDrawCondition() {

        int[][] boardModel = new int[][] { { 1, 0, 2 }, { 0, 2, 0 }, { 1, 1, 0 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(2L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.SUCCESS, result.getEvaluationResultType());
    }

    @Test
    public void testDrawCondition1() {

        int[][] boardModel = new int[][] { { 2, 1, 2 }, { 1, 1, 0 }, { 1, 2, 0 } };

        GameRules rules = new GameRules();
        rules.createStateForNewMatch(players);
        fillBoard(rules.getBoard(), boardModel);

        Move prefilledMove = new Move(2L, null, null);
        EvaluationResult result = rules.createAndExecuteBotMove(prefilledMove);

        assertEquals(EvaluationResult.Type.MATCH_END_DRAW, result.getEvaluationResultType());
    }

    private static void fillBoard(SequencesBoard board, int[][] model) {
        for (int line = 0; line < 3; line++) {
            for (int column = 0; column < 3; column++) {
                int c = model[line][column];
                if (c != 0) {
                    board.setCellAt(line, column, c == 1 ? 1L : 2L, String.valueOf(c).charAt(0));
                }
            }
        }
    }
}
